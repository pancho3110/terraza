export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <header className="h-screen bg-cover bg-center flex flex-col justify-center items-center text-center px-4" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1400&q=80')" }}>
        <h1 className="text-5xl font-bold mb-4">Terraza Tierra de Islas</h1>
        <p className="text-xl max-w-lg">Gastronomía con identidad chilota en el corazón de Castro</p>
      </header>

      <section className="text-center py-20">
        <h2 className="text-3xl mb-4">Explora Nuestro Menú</h2>
        <a href="https://menu.fu.do/terrazatierradeislaschilo%C3%A9/qr-menu" target="_blank" className="bg-gradient-to-r from-cyan-500 to-blue-500 px-6 py-3 rounded-full text-white inline-block">Ver Menú</a>
      </section>

      <section className="text-center py-20 px-4">
        <h2 className="text-3xl mb-4">Sobre Nosotros</h2>
        <p className="max-w-2xl mx-auto">"Terraza Tierra de Islas" nace del amor por la tierra chilota, su mar y su cultura. Nuestro equipo busca transmitir esa pasión a través de cada plato, usando productos frescos y de origen local, ofreciendo un espacio acogedor con vistas inolvidables.</p>
      </section>

      <section className="py-20 px-4">
        <h2 className="text-3xl text-center mb-8">Galería</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <img src="https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=800&q=80" className="rounded-xl" />
          <img src="https://images.unsplash.com/photo-1550966871-3ed1c5f0eeb2?auto=format&fit=crop&w=800&q=80" className="rounded-xl" />
          <img src="https://images.unsplash.com/photo-1617191519403-cba5f3c46031?auto=format&fit=crop&w=800&q=80" className="rounded-xl" />
        </div>
      </section>

      <section className="text-center py-20 px-4">
        <h2 className="text-3xl mb-4">Contacto</h2>
        <p>Dirección: Balmaceda 229, Castro, Chiloé</p>
        <p>Teléfono: +56 9 1234 5678</p>
        <p>Email: contacto@terrazatierradeislas.cl</p>
        <p><a href="https://wa.me/56912345678" target="_blank" className="text-green-400 underline">Escríbenos por WhatsApp</a></p>
        <p>Síguenos en <a href="https://www.instagram.com/terraza.tierradeislas/" className="text-blue-400 underline" target="_blank">Instagram</a></p>
      </section>

      <footer className="bg-[#111] text-white text-center py-6 text-sm">
        &copy; 2025 Terraza Tierra de Islas - Todos los derechos reservados.
      </footer>
    </div>
  )
}